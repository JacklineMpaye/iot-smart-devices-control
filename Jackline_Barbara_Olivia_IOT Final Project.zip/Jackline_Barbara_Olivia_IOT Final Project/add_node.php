<?php
// Include your database connection file
include('./config2.php');  

// Get the POST data
$data = json_decode(file_get_contents('php://input'), true);

// Extract the necessary fields from the incoming JSON
if (isset($data['node_name']) && isset($data['location'])) {
    $nodeName = $data['node_name'];
    $location = $data['location'];

    // Prepare the SQL statement to insert the node into the database
    $stmt = $conn->prepare("INSERT INTO smart_nodes (node_name, location) VALUES (?, ?)");
    
    if ($stmt === false) {
        echo json_encode(['success' => false, 'message' => 'Error preparing statement: ' . $conn->error]);
        exit;
    }

    // Bind parameters and execute the query
    $stmt->bind_param("ss", $nodeName, $location);

    // Execute the query and check if it was successful
    if ($stmt->execute()) {
        // Return a success message in JSON format
        echo json_encode(['success' => true]);
    } else {
        // Return an error message in JSON format
        echo json_encode([
            'success' => false,
            'message' => 'Error adding node: ' . $stmt->error
        ]);
    }

    // Close the statement
    $stmt->close();
} else {
    // Return an error if the necessary data is missing
    echo json_encode(['success' => false, 'message' => 'Invalid input.']);
}

// Close the database connection
$conn->close();
?>
