<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Smart Node Management</title>
    <style>
        /* Same styling as before */
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            background-color: #121212;
            color: #f5f5f5;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
        }

        .container {
            text-align: center;
            background: #1e1e1e;
            padding: 30px 40px;
            border-radius: 15px;
            box-shadow: 0 6px 15px rgba(0, 0, 0, 0.3);
            width: 90%;
            max-width: 600px;
        }

        h1 {
            font-size: 26px;
            margin-bottom: 20px;
            color: #1e90ff;
        }

        button {
            padding: 12px 25px;
            margin: 10px;
            border: none;
            border-radius: 8px;
            cursor: pointer;
            font-size: 16px;
            transition: background-color 0.3s ease;
            background-color: #0288d1;
            color: white;
        }

        button:hover {
            background-color: #0277bd;
        }

        input, select {
            padding: 10px;
            margin: 10px;
            font-size: 16px;
            width: 80%;
            border: 1px solid #444;
            border-radius: 8px;
            color: #121212;
        }

        table {
            width: 100%;
            margin-top: 20px;
            border-collapse: collapse;
        }

        table th, table td {
            padding: 10px;
            border: 1px solid #444;
            text-align: left;
        }

        table th {
            background-color: #1e90ff;
        }

        table td {
            background-color: #2a2a2a;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>Smart Node Management</h1>

        <!-- Add New Smart Node -->
        <h2>Add a New Smart Node</h2>
        <form id="addNodeForm">
            <label for="descriptiveName">Node Name:</label>
            <input type="text" id="descriptiveName" name="descriptiveName" placeholder="Enter descriptive name" required>
            <br>
            <label for="location">Location:</label><br>
            <input type="text" id="location" name="location" placeholder="Enter location" required>
            <br>
            <button type="submit">Add Node</button>
        </form>
        <p id="addNodeMessage"></p>

        <!-- Smart Node Table -->
        <h2>Smart Node Table</h2>
        <table id="nodeTable">
            <thead>
                <tr>
                    <th>Node ID</th>
                    <th>Node Name</th>
                    <th>Location</th>
                </tr>
            </thead>
            <tbody>
                <!-- Table rows will be populated by JavaScript -->
            </tbody>
        </table>

        <!-- Select and View Node Information -->
        <h2>View Node Information</h2>
        <label for="nodeSelector">Select Node:</label>
        <select id="nodeSelector">
            <option value="">--Select Node--</option>
            <!-- Dropdown options will be populated by JavaScript -->
        </select>
        <p id="nodeDetails"></p>

        <!-- Display Sensor Readings -->
        <h2>Sensor Readings</h2>
        <div id="SensorReadings">
            <p>No readings available</p>
        </div>
    </div>

    <script>
        // Load nodes from the database when the page loads
        window.addEventListener('load', async () => {
            try {
                const response = await fetch('get_node_details.php'); // Fetch nodes from the backend
                const nodes = await response.json();

                // Populate the node table
                const nodeTableBody = document.getElementById('nodeTable').getElementsByTagName('tbody')[0];
                const nodeSelector = document.getElementById('nodeSelector');

                nodes.forEach(node => {
                    // Create a new row for the node table
                    const row = nodeTableBody.insertRow();
                    row.insertCell(0).textContent = node.nodeID;
                    row.insertCell(1).textContent = node.node_name;
                    row.insertCell(2).textContent = node.location;

                    // Create a new option for the nodeSelector dropdown
                    const option = document.createElement('option');
                    option.value = node.nodeID;
                    option.textContent = node.node_name;
                    nodeSelector.appendChild(option);
                });
            } catch (error) {
                console.error('Error loading nodes:', error);
            }
        });

        // Handle form submission to add a new node
        document.getElementById('addNodeForm').addEventListener('submit', async function (e) {
            e.preventDefault();

            const nodeName = document.getElementById('descriptiveName').value;
            const location = document.getElementById('location').value;

            try {
                // Send the data to add_node.php using a POST request
                const response = await fetch('./add_node.php', {
                    method: 'POST',
                    body: JSON.stringify({ node_name: nodeName, location: location }),
                    headers: {
                        'Content-Type': 'application/json'
                    }
                });
                

                const result = await response.json();

                if (result.success) {
                    alert('Node added successfully!');
                    // Reload nodes and update the UI
                    window.location.reload();
                } else {
                    alert('Failed to add node: ' + result.message);
                }
            } catch (error) {
                console.error('Error adding node:', error);
                // alert('Error adding node. Please try again later.');
                
            }
        });

        // Fetch sensor readings for a selected node
        document.getElementById('nodeSelector').addEventListener('change', async function () {
            const selectedID = this.value;
            const sensorReadingsDiv = document.getElementById('SensorReadings');

            if (!selectedID) {
                sensorReadingsDiv.innerHTML = '<p>No readings available</p>';
                return;
            }

            try {
                // Fetch sensor readings for the selected node
                const response = await fetch(`process.php?nodeID=${selectedID}`);  // Pass nodeID in the URL
                const data = await response.json();

                if (Array.isArray(data) && data.length > 0) {
                    let readingsHTML = '<table>';
                    readingsHTML += '<tr><th>Sensor Name</th><th>Reading</th><th>Timestamp</th></tr>';

                    // Loop through the data and create table rows for each sensor reading
                    data.forEach(reading => {
                        readingsHTML += `
                            <tr>
                                <td>${reading.sensor_name}</td>
                                <td>${reading.reading}</td>
                                <td>${reading.timestamp}</td>
                            </tr>`;
                    });

                    readingsHTML += '</table>';
                    sensorReadingsDiv.innerHTML = readingsHTML;
                } else {
                    sensorReadingsDiv.innerHTML = '<p>No readings available for the selected node.</p>';
                }
            } catch (error) {
                console.error('Error fetching sensor data:', error);
                sensorReadingsDiv.innerHTML = '<p>Error fetching sensor readings. Please try again later.</p>';
            }
        });

    </script>
</body>
</html>
