<?php
// Database connection
$servername = "localhost";
$username = "root"; // Replace with your database username
$password = ""; // Replace with your database password
$dbname = "sensor_info"; // Replace with your database name

$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$node_id = isset($_GET['nodeID']) ? $_GET['nodeID'] : null; // Get the nodeID from query string

// Ensure nodeID is provided
if (!$node_id) {
    echo json_encode([]);
    exit();
}

// Fetch sensor readings based on nodeID
$sql = "SELECT sensor_info.SensorName, sensor_info.SensorReading, sensor_info.recordDate, smarts_nodes.node_name, smarts_nodes.location FROM sensor_info JOIN smarts_nodes ON sensor_info.nodeID = smarts_nodes.nodeID WHERE sensor_info.nodeID = ?;
"; // Adjust table and fields as needed
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $node_id);
$stmt->execute();
$result = $stmt->get_result();

$sensor_data = [];
if ($result->num_rows > 0) {
    while($row = $result->fetch_assoc()) {
        $sensor_data[] = $row;
    }
}

// Return sensor data as JSON
echo json_encode($sensor_data);

$stmt->close();
$conn->close();
?>
