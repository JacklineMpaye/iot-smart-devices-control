#this code is ok. simple, tested
import paho.mqtt
import paho.mqtt.subscribe as subscribe 
import requests
import json

MQTT_SERVER = "192.168.137.32"
MQTT_PATH = "AshesiIotTopic/#"
def on_message(client, userdata, message):
	print("{} : {}".format(message.topic, message.payload))
	payload = message.payload.decode('utf-8')
	data = json.loads(payload)
	SOwner = data.get("SOwner", "Unknown")
	value = data.get("SensorReading", "Unknown")
	name = data.get("SensorName", "Unknown")
	code = data.get("Code", "Unknown")

	response = requests.post("http://192.168.137.32/IOT/fetchAPI/arduino_part/processing_unit.php", json = {"SOwner": SOwner, "Code": code, 'SensorName': name, 'SensorReading': value})

print("starting")
subscribe.callback(on_message, topics=MQTT_PATH,hostname=MQTT_SERVER)
 

