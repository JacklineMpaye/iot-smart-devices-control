const char HOME_PAGE_HTML[] PROGMEM = R"rawliteral(
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Smart Objects Dashboard</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            background-color: #121212;
            color: #f5f5f5;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
        }

        .container {
            text-align: center;
            background: #1e1e1e;
            padding: 30px 40px;
            border-radius: 15px;
            box-shadow: 0 6px 15px rgba(0, 0, 0, 0.3);
            width: 90%;
            max-width: 600px;
        }

        h1 {
            font-size: 26px;
            margin-bottom: 20px;
            color: #1e90ff;
        }

        button {
            padding: 12px 25px;
            margin: 10px;
            border: none;
            border-radius: 8px;
            cursor: pointer;
            font-size: 16px;
            transition: background-color 0.3s ease;
            background-color: #0288d1;
            color: white;
        }

        button:hover {
            background-color: #0277bd;
        }

        .sensor-values {
            margin-top: 20px;
            padding: 15px;
            background: #222;
            border-radius: 10px;
        }

        table {
            width: 100%;
            margin-top: 20px;
            border-collapse: collapse;
        }

        table th, table td {
            padding: 10px;
            border: 1px solid #444;
            text-align: left;
        }

        table th {
            background-color: #1e90ff;
        }

        table td {
            background-color: #2a2a2a;
        }
        .ldr-para {
            font-size: 12px; /* Reduce font size */
            max-height: 200px; /* Set max height to prevent overflowing */
            overflow-y: auto; /* Make content scrollable if it exceeds max-height */
            white-space: pre-wrap; /* Preserve whitespace formatting */
        }
         /* Styling the Configure Node link */
        #configure-node {
            position: absolute;
            top: 10px;
            right: 10px;
            font-size: 16px;
            color: #1e90ff;
            text-decoration: none;
            background-color: transparent;
            padding: 5px 10px;
            border: 2px solid #1e90ff;
            border-radius: 8px;
            transition: background-color 0.3s ease;
        }

        #configure-node:hover {
            background-color: #1e90ff;
            color: #fff;
        }

    </style>
    <script>
        // This function will navigate to the settings page
        function goToSettings() {
            window.location.href = "/settings";
        }

        async function fetchTemperature(deviceName, elementId) {
          
            try {
                const response = await fetch(`/readSensor?sensor=${deviceName}`);
                if (response.ok) {
                    const payload = await response.text();
                    document.getElementById(elementId).innerText = `${deviceName}: ${payload}`;
                } else {
                    document.getElementById(elementId).innerText = "Response bad Error fetching data";
                }
            } catch (error) {
                
            }
        }
    </script>
    
</head>
<body>
     <script>
        function sendRequest(url) {
          fetch(url)
            .then(response => response.text())
            .then(data => console.log(data));
        }
        
        async function fetchTemp(deviceName, elementId) {
          try{ 

          const response = await fetch(`/readSensor?sensor=${deviceName}`);
                if (response.ok) {
                    const payload = await response.text();
                    const dataArray = JSON.parse(payload);
                    console.log(dataArray);

                  // Get the first dictionary (object) in the array
                    const firstDictionary = dataArray[0];

                    document.getElementById(elementId).innerText = `${deviceName}: ${firstDictionary.SensorReading}`;
                    console.log(firstDictionary.SensorName);    // Output: Temperature

                } else {
                    document.getElementById(elementId).innerText = "bad response Error fetching data";
                }
              }catch{

              }
            
                
        }
        
        function updateSensorValues() {
          fetchTemp("ldr", "ldr-value");
          fetchTemp("dht" ,"dht-value");
          fetchTemp("humidity", "humidity-value");
        }
        function update_five() {
          setInterval(() => {
            updateSensorValues();
          }, 10000);
        }
        update_five();
        // Function to fetch and display the updated device name from localStorage
        function updateDeviceNameDisplay() {
          let value = localStorage.getItem("newName");
          if (value != null){
            document.getElementById("dashboard-title").innerText = value;
          }
          else{
            document.getElementById("dashboard-title").innerText = "Node 2";
          }
        }

        // Update the device name when the page loads
        window.onload = function() {
            updateDeviceNameDisplay();}
    </script>
    <div class="container">
        <button id="configure-node" onclick="goToSettings()">Configure Node</button>

        
        <h1 id="dashboard-title">Node 2</h1>

        <div class="button-group">
            <button id="start-ac" onclick="sendRequest('/startAC')">Start AC</button>
            <button id="stop-ac" onclick="sendRequest('/stopAC')">Stop AC</button>
        </div>

        <div class="sensor-values">
            <h2>Current Sensor Values</h2>
            <p id="dht-value">DHT: Loading...</p>
            <p id="humidity-value">Humidity: Loading...</p>
            <p id="ldr-value">LDR: Loading...</p>
        </div>
         
        
        <button id="view-ldr-data" onclick="fetchTemperature('ldr', 'ldr-para')">View Last 15 LDR Values</button>

        <p id="ldr-para" class ="ldr-para"></p>
        
    </div>

    
</body>
</html>
)rawliteral";