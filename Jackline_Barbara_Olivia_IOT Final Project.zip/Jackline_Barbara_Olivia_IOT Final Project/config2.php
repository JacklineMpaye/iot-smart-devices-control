<?php

//local
$servername= "localhost";
$username="root";
$password="";
$dbname="smart_nodes";


$con = mysqli_connect($servername,$username,$password,$dbname) or die ("could not connect database");


?>