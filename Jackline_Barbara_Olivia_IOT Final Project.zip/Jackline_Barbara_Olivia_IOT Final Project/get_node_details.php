<?php
include('config2.php'); // Include the database connection

// Get the nodeID from the URL query string
$nodeID = isset($_GET['nodeID']) ? intval($_GET['nodeID']) : 0;

// Query to fetch node details
$query = "SELECT sensor_info.SensorName, sensor_info.SensorReading, sensor_info.recordDate, smarts_nodes.node_name, smarts_nodes.location 
          FROM sensor_info 
          JOIN smarts_nodes ON sensor_info.nodeID = smarts_nodes.nodeID 
          WHERE sensor_info.nodeID = ?";

$stmt = $conn->prepare($query);
$stmt->bind_param("i", $nodeID);
$stmt->execute();
$result = $stmt->get_result();

$nodeDetails = [];

if ($result->num_rows > 0) {
    // Fetch all rows and store them in an array
    while ($row = $result->fetch_assoc()) {
        $nodeDetails[] = $row;
    }
    echo json_encode($nodeDetails); // Return the entire array as a JSON response
} else {
    echo json_encode(null); // If no data found, return null
}
?>
