<?php
include "config.php";
ini_set('display_errors', 0);
error_reporting(0);

$method = $_SERVER['REQUEST_METHOD'];

switch ($method) {
    case 'POST':
        // Retrieve JSON input and decode it
        $data = json_decode(file_get_contents('php://input'), true);

        // Assign input to variables (Updated variable names: nodeName and location)
        $nodeName = $data['nodeName'];
        $location = $data['location'];
        $sensorName = $data['SensorName'];
        $sensorReading = (int) $data['SensorReading'];

        // Prepare and execute SQL statement for insertion
        $sql = 'INSERT INTO sensor_info (NodeName, Location, SensorName, SensorReading) VALUES (?, ?, ?, ?)';
        $stmt = mysqli_prepare($con, $sql);

        if ($stmt) {
            mysqli_stmt_bind_param($stmt, "sssi", $nodeName, $location, $sensorName, $sensorReading);
            mysqli_stmt_execute($stmt);

            // Check for successful insertion
            if (mysqli_stmt_affected_rows($stmt) > 0) {
                echo json_encode(['message' => 'Sensor data added successfully']);
            } else {
                echo json_encode(['error' => 'Failed to add sensor data']);
            }

            mysqli_stmt_close($stmt);
        } else {
            echo json_encode(['error' => 'Database error: Failed to prepare statement']);
        }
        break;

    case 'GET':
        $name = null;
        if (isset($_GET["sen"])) {
            $name = $_GET["sen"];
        }

        // Prepare SQL to fetch data for a specific sensor
        $sql = "SELECT * FROM sensor_info WHERE SensorName = ? ORDER BY RecordID DESC LIMIT 15";
        $stmt = mysqli_prepare($con, $sql);

        if ($stmt) {
            // Bind parameters and execute
            mysqli_stmt_bind_param($stmt, "s", $name);
            mysqli_stmt_execute($stmt);

            // Fetch results
            $result = mysqli_stmt_get_result($stmt);

            if ($result) {
                $data = [];
                while ($row = mysqli_fetch_assoc($result)) {
                    $data[] = $row;
                }
                echo json_encode($data);
            } else {
                echo json_encode(['message' => 'No data found']);
            }

            mysqli_stmt_close($stmt);
        } else {
            echo json_encode(['error' => 'Failed to prepare the statement']);
        }
        break;

    default:
        echo json_encode(['error' => 'Unsupported request method']);
        break;
}
?>
