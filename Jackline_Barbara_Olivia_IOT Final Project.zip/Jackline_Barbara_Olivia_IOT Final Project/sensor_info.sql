-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Nov 05, 2024 at 03:40 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `my_db`
--

-- --------------------------------------------------------

--
-- Table structure for table `sensor_info`
--

CREATE TABLE `sensor_info` (
  `RecordID` int(11) NOT NULL,
  `RecordDate` timestamp NOT NULL DEFAULT current_timestamp(),
  `SOwner` varchar(25) NOT NULL,
  `Code` varchar(25) NOT NULL,
  `SensorName` varchar(25) NOT NULL,
  `SensorReading` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `sensor_info`
--

INSERT INTO `sensor_info` (`RecordID`, `RecordDate`, `SOwner`, `Code`, `SensorName`, `SensorReading`) VALUES
(1, '2024-11-05 14:37:49', 'Barba', '34672025', 'UltraSonic', 14),
(2, '2024-11-05 14:37:55', 'Barba', '34672025', 'UltraSonic', 15),
(3, '2024-11-05 14:37:57', 'Barba', '34672025', 'LDR', 4095),
(4, '2024-11-05 14:38:01', 'Barba', '34672025', 'UltraSonic', 15),
(5, '2024-11-05 14:38:03', 'Barba', '34672025', 'LDR', 4095),
(6, '2024-11-05 14:38:07', 'Barba', '34672025', 'UltraSonic', 15),
(7, '2024-11-05 14:38:09', 'Barba', '34672025', 'LDR', 4095),
(8, '2024-11-05 14:38:13', 'Barba', '34672025', 'UltraSonic', 15),
(9, '2024-11-05 14:38:19', 'Barba', '34672025', 'UltraSonic', 1194),
(10, '2024-11-05 14:38:20', 'Barba', '34672025', 'LDR', 4095),
(11, '2024-11-05 14:38:25', 'Barba', '34672025', 'UltraSonic', 4),
(12, '2024-11-05 14:38:30', 'Barba', '34672025', 'UltraSonic', 4),
(13, '2024-11-05 14:38:32', 'Barba', '34672025', 'LDR', 4095),
(14, '2024-11-05 14:38:36', 'Barba', '34672025', 'UltraSonic', 4),
(15, '2024-11-05 14:38:42', 'Barba', '34672025', 'UltraSonic', 4);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `sensor_info`
--
ALTER TABLE `sensor_info`
  ADD PRIMARY KEY (`RecordID`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `sensor_info`
--
ALTER TABLE `sensor_info`
  MODIFY `RecordID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
