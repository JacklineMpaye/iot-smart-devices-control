<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Smart Node Management</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 20px;
            background-color: #f0f8ff; /* Light blue background */
            color: #003366; /* Dark blue text */
        }
        h1 {
            color: #003366;
            text-align: center;
        }
        label {
            margin-right: 10px;
            color: #003366;
        }
        input, select, button {
            margin: 5px;
            padding: 8px;
            font-size: 16px;
            border: 1px solid #003366;
            border-radius: 5px;
            box-sizing: border-box;
        }
        input, select {
            width: 250px; /* Ensure all inputs have the same width */
            max-width: 100%;
        }
        button {
            background-color: #003366;
            color: white;
            cursor: pointer;
        }
        button:hover {
            background-color: #00509e;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
            background-color: #ffffff; /* White table background */
            box-shadow: 0px 4px 6px rgba(0, 0, 0, 0.1);
        }
        th, td {
            border: 1px solid #003366;
            padding: 8px;
            text-align: left;
        }
        th {
            background-color: #003366; /* Dark blue header background */
            color: white;
        }
        td {
            color: #003366;
        }
        td[colspan] {
            text-align: center;
            font-style: italic;
        }
        .form-row {
            display: flex;
            align-items: center;
            justify-content: center;
            flex-wrap: wrap;
            gap: 10px; /* Space between elements */
            margin-bottom: 15px;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>Smart Node Management</h1>

        <!-- Add New Smart Node -->
        <h2>Add a New Smart Node</h2>
        <form id="addNodeForm">
            <label for="nodeName">Node Name:</label>
            <input type="text" id="nodeName" name="nodeName" required><br>
            <label for="location">Location:</label>
            <input type="text" id="location" name="location" required><br>
            <button type="submit">Submit</button>
        </form>
        <p id="addNodeMessage"></p>

        <!-- Select and View Historical Data -->
        <h2>View Historical Data</h2>
        <label for="nodeSelector">Select a Node:</label>
        <select id="nodeSelector" onchange="viewNodeData()">
            <option value="">--Select Node--</option>
            <option value="Node1">Node 1</option>
            <option value="Node2">Node 2</option>
            <option value="Node3">Node 3</option>
        </select>

        <table id="dataTable">
            <thead>
                <tr>
                    <th>Record Date</th>
                    <th>Sensor Name</th>
                    <th>Sensor Reading</th>
                </tr>
            </thead>
            <tbody>
                <tr>
                    <td colspan="3">No data to display</td>
                </tr>
            </tbody>
        </table>
    </div>

    <script>
        document.getElementById('addNodeForm').addEventListener('submit', function (e) {
            e.preventDefault();

            const nodeName = document.getElementById('nodeName').value;
            const location = document.getElementById('location').value;

            fetch('backend.php', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/x-www-form-urlencoded'
                },
                body: `addNode=true&nodeName=${nodeName}&location=${location}`
            })
            .then(response => response.json())
            .then(data => {
                const message = document.getElementById('addNodeMessage');
                if (data.success) {
                    message.textContent = data.message;
                    message.style.color = 'green';
                } else {
                    message.textContent = data.message;
                    message.style.color = 'red';
                }
            });
        });

        function viewNodeData() {
            const node = document.getElementById('nodeSelector').value;
            const dataTable = document.getElementById('dataTable').getElementsByTagName('tbody')[0];

            dataTable.innerHTML = '';

            if (node) {
                fetch(`backend.php?node=${node}`)
                    .then(response => response.json())
                    .then(data => {
                        if (data.length > 0) {
                            data.forEach(entry => {
                                const row = dataTable.insertRow();
                                const cell1 = row.insertCell(0);
                                const cell2 = row.insertCell(1);
                                const cell3 = row.insertCell(2);

                                cell1.textContent = entry.RecordDate;
                                cell2.textContent = entry.SensorName;
                                cell3.textContent = entry.SensorReading;
                            });
                        } else {
                            const row = dataTable.insertRow();
                            const cell = row.insertCell(0);
                            cell.colSpan = 3;
                            cell.textContent = 'No data available for the selected node.';
                        }
                    })mmk;;,
                    .catch(error => console.error('Error fetching data:', error));
            } else {
                const row = dataTable.insertRow();
                const cell = row.insertCell(0);
                cell.colSpan = 3;
                cell.textContent = 'Please select a node to view data.';
            }
        }
    </script>
</body>
</html>
