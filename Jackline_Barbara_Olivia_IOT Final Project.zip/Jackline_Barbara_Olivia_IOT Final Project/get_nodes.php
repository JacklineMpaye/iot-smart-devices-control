<?php
include('db_connection.php'); // Include the database connection

// Query to fetch node details
$query = "SELECT nodeID, node_name, location FROM smart_nodes";
$result = $conn->query($query);

$nodes = [];
while ($row = $result->fetch_assoc()) {
    $nodes[] = $row;
}

// Return the node data as JSON
echo json_encode($nodes);
?>
