#ifndef SETTINGSPAGE_H
#define SETTINGSPAGE_H

const char SETTINGS_PAGE_HTML[] PROGMEM = R"rawliteral(
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>IoT Project Settings</title>
    <style>
        body {
            font-family: 'Arial', sans-serif;
            margin: 0;
            padding: 0;
            background: linear-gradient(135deg, #050505, #010101);
            color: #333;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
        }
        .container {
            background: white;
            padding: 30px 40px;
            border-radius: 15px;
            box-shadow: 0 6px 15px rgba(0, 0, 0, 0.1);
            text-align: center;
            width: 90%;
            max-width: 600px;
        }
        h1 {
            font-size: 26px;
            margin-bottom: 20px;
            color: #1e90ff;
        }
        label {
            display: block;
            margin: 10px 0;
            font-size: 16px;
        }
        input, select, button {
            width: 100%;
            margin: 5px 0 15px;
            padding: 10px;
            font-size: 16px;
            border: 1px solid #ccc;
            border-radius: 8px;
        }
        button {
            background-color: #1e90ff;
            color: white;
            cursor: pointer;
            border: none;
        }
        button:hover {
            background-color: #1e90ff;
        }
        .switch-container {
            text-align: left;
            margin-bottom: 15px;
        }
        .switch-label {
            font-size: 16px;
            display: flex;
            align-items: center;
        }
        .switch {
            margin-left: auto;
        }
    </style>
    <script>
    
      
    

    // function validate(){
    //   var id = document.getElementById("connection-method");
    //    var selectedVal = id.options[id.selectedIndex].value;
        
    //         // Sending data to the server using fetch
    //   fetch('/changePost', {
    //     method: 'POST', // HTTP method
    //     headers: {
    //       'Content-Type': 'application/json' // Sending JSON data
    //   },
    //     body: JSON.stringify({"method": selectedVal, "sensor":deviceName}) // Convert the value to JSON
    //     })
    //   .then(response => {
    //     if (response.ok) {
    //       console.log('Data sent successfully');
    //     } 
    //     else {
    //       console.error('Failed to send data');
    //       }
    //   })
    //   .catch(error => console.error('Error:', error));       
    // }

    function toggleAutoMode(checkbox) {
    // Define the URL to be called based on the checkbox state
      const url = checkbox.checked ? "/autoF" : "/disconnect";

        // Use fetch to send a request to the server
      fetch(url, {
          method: 'GET', // You can use 'POST' if you prefer, but 'GET' is common for simple requests
      })
      .then(response => {
        if (!response.ok) {
          throw new Error('Network response was not ok');
        }
        return response.text(); // Or response.json() if you expect a JSON response
        })
      .then(data => {
        console.log('Server response:', data);
          // Optionally, you can handle the response here if needed
      })
      .catch(error => {
        console.error('There was a problem with the fetch operation:', error);
      });
    }

    function updateDeviceName(originalName, newName) {
            const devices = JSON.parse(localStorage.getItem("devices")) || [];
            devices.forEach(device => {
                if (device.originalName === originalName) {
                    device.displayName = newName;
                }
            });
            localStorage.setItem("devices", JSON.stringify(devices));
        }

        // Function to handle the button click and save the new name
        function handleSaveSettings() {
            const originalName = "Node 2";  // The default name you want to change
            const newName = document.getElementById("new-device-name").value;
            // Log newName and make it globally accessible
            localStorage.setItem("newName", newName);

            if (newName.trim()) {
                updateDeviceName(originalName, newName);
                alert("Node name updated successfully!");
            } else {
                alert("Please enter a valid name.");
            }
        }

    

    </script>
</head>
<body>
    
    <div class="container">
        <h1>Settings</h1>
        <p>Configure your Smart object settings here.</p>

        

        <form id="post-method-form" action="/changePost" method="post">
          <label for="connection-method">Connection Method:</label>
          <select id="connection-method" name="method"> 
              <option value="regular">HTTP</option>
              <option value="mqtt">MQTT</option>
              
          </select>
          <button type="submit">Change Method</button>
        </form>

        

        
        <!-- Manual/Auto Control -->
        <div class="switch-container">
            <label class="switch-label">
                Manual/Auto Mode:
                <input type="checkbox" id="manual-auto" class="switch" onchange="toggleAutoMode(this)">
            </label>
        </div>

        <form id="threshold-form" action="/setThreshold" method="post">
          <label for="trigger-temperature">Trigger Temperature (C):</label>
          <input type="number" id="trigger-temperature" name="threshold" placeholder="Enter trigger temperature" required>
          <button type="submit">Set Threshold</button>
        </form>


        <label for="new-device-name">Enter New Node Name:</label>
        <input type="text" id="new-device-name" placeholder="Enter new name here">
        <br>
        <button class="save-button" id="save-settings" onclick="handleSaveSettings()">Save New Node Name</button>

        <!-- Back to Homepage Button -->
        <button id="back-home" onclick="window.location.href='/'">Back to Homepage</button>
    </div>
    
</body>
</html>
)rawliteral";
#endif  // SETTINGSPAGE_H