const char HOME_PAGE_HTML[] PROGMEM = R"rawliteral(
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Smart Objects Dashboard</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            background-color: #121212;
            color: #f5f5f5;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
        }

        .container {
            text-align: center;
            background: #1e1e1e;
            padding: 30px 40px;
            border-radius: 15px;
            box-shadow: 0 6px 15px rgba(0, 0, 0, 0.3);
            width: 90%;
            max-width: 600px;
        }

        h1 {
            font-size: 26px;
            margin-bottom: 20px;
            color: #1e90ff;
        }

        .button-group {
            margin: 20px 0;
        }

        button {
            padding: 12px 25px;
            margin: 10px;
            border: none;
            border-radius: 8px;
            cursor: pointer;
            font-size: 16px;
            transition: background-color 0.3s ease;
            background-color: #0288d1;
            color: white;
        }

        button:hover {
            background-color: #0277bd;
        }

        .device-buttons-container {
            display: flex;
            flex-wrap: wrap;
            justify-content: center;
            gap: 10px;
            margin-top: 20px;
        }

        .device-button {
            display: block;
            margin: 15px;
            background-color: #1976d2;
            color: white;
            border-radius: 8px;
            padding: 10px 20px;
            cursor: pointer;
            font-size: 16px;
        }

        .device-button:hover {
            background-color: #1565c0;
        }

        .action-buttons {
            display: none;
            flex-direction: column;
            align-items: center;
            margin-top: 10px;
        }

        .action-buttons button {
            background-color: #0288d1;
            margin: 5px;
        }

        .action-buttons button:hover {
            background-color: #0277bd;
        }
        .temperature-display {
            font-size: 12px; /* Reduce font size */
            max-height: 200px; /* Set max height to prevent overflowing */
            overflow-y: auto; /* Make content scrollable if it exceeds max-height */
            white-space: pre-wrap; /* Preserve whitespace formatting */
  }

        .value-display {
            margin-top: 10px;
            font-size: 14px;
            color: #ccc;
            padding: 10px;
            border: 1px solid #444;
            border-radius: 5px;
            background: #222;
            display: none;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>Smart Object Dashboard</h1>

        <div class="button-group">
            <label>
                <input type="radio" id="add-device-radio" name="device-radio"> Add New Device (Node)
            </label>
            <select id="device-select" class="hidden">
                <option value="">Select Device</option>
                <option value="dht">Temperature sensor</option>
                <option value="Humidity">Humidity sensor</option>
                <option value="ldr">Light sensor</option>
            </select>
        </div>

        <div class="device-buttons-container" id="dynamic-device-buttons"></div>

        <div class="button-group">
            <button id="start-ac" onclick='sendRequest("/startAC")'>Start AC</button>
            <button id="stop-ac" onclick='sendRequest("/stopAC")'>Stop AC</button>
        </div>
    </div>

    <script>
      function sendRequest(url) {
        fetch(url)
          .then(response => response.text())
          .then(data => console.log(data));
      }
        const addDeviceRadio = document.getElementById("add-device-radio");
        const deviceSelect = document.getElementById("device-select");
        const dynamicDeviceButtons = document.getElementById("dynamic-device-buttons");

        document.addEventListener("DOMContentLoaded", () => {
            const savedDevices = JSON.parse(localStorage.getItem("devices")) || [];
            savedDevices.forEach(device => {
                if (device.name) { // Ensure device.name is not empty or null
                    createDeviceButton(device.name);
                }
            });
});
        addDeviceRadio.addEventListener("click", () => {
            deviceSelect.classList.toggle("hidden", !addDeviceRadio.checked);
        });

        deviceSelect.addEventListener("change", () => {
            const selectedDevice = deviceSelect.value;
            if (selectedDevice) {
                createDeviceButton(selectedDevice, selectedDevice);
                saveDevice(selectedDevice, selectedDevice);
            }
        });

        function createDeviceButton(originalName, displayName) {
            const uniqueId = Date.now(); // Generate a unique ID for the element

            const deviceButton = document.createElement("button");
            deviceButton.textContent = displayName;
            deviceButton.classList.add("device-button");

            const actionButtonsContainer = document.createElement("div");
            actionButtonsContainer.classList.add("action-buttons");

            const uploadButton = document.createElement("button");
            uploadButton.textContent = "Upload";
            uploadButton.onclick = () => window.location.href = "/settings";

            const editButton = document.createElement("button");
            editButton.textContent = "Edit";
            editButton.onclick = () => {
                const newName = prompt("Enter new device name:", displayName);
                if (newName) {
                    deviceButton.textContent = newName;
                    updateDeviceName(originalName, newName);
                }
            };

            const viewValuesButton = document.createElement("button");
            viewValuesButton.textContent = "View Values";

            const temperatureDisplay = document.createElement("p");
            temperatureDisplay.id = temperature-${uniqueId};
            temperatureDisplay.textContent = "Loading...";
            temperatureDisplay.style.display = "none";
            temperatureDisplay.style.marginTop = "5px";
            temperatureDisplay.classList.add("temperature-display"); // Add class for styling

            viewValuesButton.addEventListener("click", () => {
                temperatureDisplay.style.display = "block";
                startFetchingTemperature(originalName, temperatureDisplay.id);
            });

            actionButtonsContainer.append(uploadButton, editButton, viewValuesButton, temperatureDisplay);
            dynamicDeviceButtons.append(deviceButton, actionButtonsContainer);

            deviceButton.addEventListener("click", () => {
                actionButtonsContainer.style.display = actionButtonsContainer.style.display === "none" ? "flex" : "none";
            });

            actionButtonsContainer.style.display = "none";
        }

        async function fetchTemperature(deviceName, elementId) {
          console.log(deviceName);
          console.log(elementId);
            try {
                const response = await fetch(/readSensor?sensor=${deviceName});
                if (response.ok) {
                    const payload = await response.text();
                    document.getElementById(elementId).innerText = ${deviceName}: ${payload};
                } else {
                    document.getElementById(elementId).innerText = "Error fetching data";
                }
            } catch (error) {
                document.getElementById(elementId).innerText = "Error fetching data";
            }
        }
        function startFetchingTemperature(deviceName, elementId) {
          console.log(deviceName);
          setInterval(() => {
              fetchTemperature(deviceName, elementId);
          }, 5000);
        }

        function saveDevice(originalName, displayName) {
            const devices = JSON.parse(localStorage.getItem("devices")) || [];
            devices.push({ originalName, displayName });
            localStorage.setItem("devices", JSON.stringify(devices));
        }

        function updateDeviceName(originalName, newName) {
            const devices = JSON.parse(localStorage.getItem("devices")) || [];
            devices.forEach(device => {
                if (device.originalName === originalName) {
                    device.displayName = newName;
                }
            });
            localStorage.setItem("devices", JSON.stringify(devices));
        }
    </script>
</body>
</html>
)rawliteral";